module.exports = {
	format: 'text',
	ignore: 'Warning: The “type” attribute is unnecessary for JavaScript resources.'
	// validator: 'http://html5.validator.nu'
};
