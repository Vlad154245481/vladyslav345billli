module.exports = {
	discardComments: {
		removeAllButFirst: true
	},
	normalizeWhitespace: true
};
