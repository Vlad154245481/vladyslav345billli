$(function() {
	const $block = $('.header');
	if (!$block.length) {
		return;
	}
});
